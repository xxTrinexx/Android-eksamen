package com.example.friendsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Frontpage extends AppCompatActivity {

    Button callGoTo;
    ImageView image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frontpage);


        callGoTo = findViewById(R.id.GoTo);
        image = findViewById(R.id.logoimage);

        Button button=(Button)findViewById(R.id.GoTo);
        button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivity(new Intent(getApplicationContext(),Login.class));

            }

});}}

